async function menuMembros(prefix) {
  return `
╭━━━━━━━━━━━━━━╮
┃🤖 *INTELIGÊNCIA ARTIFICIAL*
╰━━━━━━━━━━━━━━╯

╭──────────────╮
│  📚 *Ias de texto*
├──────────────┤
│ *${prefix}simi*
╰──────────────╯

╭━━━━━━━━━━━━━━╮
┃ 🌟 *Divirta-se e Explore!* 🌟
╰━━━━━━━━━━━━━━╯
`;
};

module.exports = menuMembros;