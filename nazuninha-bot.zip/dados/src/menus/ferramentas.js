async function menuMembros(prefix) {
  return `
╭━━━━━━━━━━━━━━╮
┃⚒️ *MENU DE FERRAMENTAS*
╰━━━━━━━━━━━━━━╯

╭──────────────╮
│  📚 *Comandos Disponíveis*
├──────────────┤
│ *${prefix}gerarnick* ou *${prefix}nick*
│ *${prefix}ssweb*
│ *${prefix}upload*
│ *${prefix}encurtalink*
╰──────────────╯

╭━━━━━━━━━━━━━━╮
┃ 🌟 *Divirta-se e Explore!* 🌟
╰━━━━━━━━━━━━━━╯
`;
}

module.exports = menuMembros;