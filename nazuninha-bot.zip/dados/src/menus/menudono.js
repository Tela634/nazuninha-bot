async function menuDono(prefix) {
  return `
╭━━━━━━━━━━━━━━╮
┃ 🌸 *MENU DO DONO* 🌸
╰━━━━━━━━━━━━━━╯

╭──────────────╮
│  📂 *Configurar Bot* 
├──────────────┤
│ *${prefix}prefixo* 
│ *${prefix}numerodono* 
│ *${prefix}nomedono* 
│ *${prefix}nomebot* 
│ *${prefix}fotomenu* 
│ *${prefix}videomenu* 
╰──────────────╯

╭──────────────╮
│  📂 *Funções de dono* 
├──────────────┤
│ *${prefix}seradm*
│ *${prefix}sermembro*
│ *${prefix}bangp*
│ *${prefix}unbangp*
│ *${prefix}addpremium*
│ *${prefix}delpremium*
╰──────────────╯

╭━━━━━━━━━━━━━━╮
┃ 🌸 *Explore e Divirta-se!* 🌸
╰━━━━━━━━━━━━━━╯
`;
}

module.exports = menuDono;