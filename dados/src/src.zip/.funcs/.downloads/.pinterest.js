const axios = require('axios');
const cheerio = require('cheerio');

async function pinterest(texto) {try {const response = await axios.get(`https://br.pinterest.com/search/pins/?q=${texto}`, { headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G975F Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36' } });const $ = cheerio.load(response.data);const fotos = [];$('.hCL').each((_, el) => {const src = $(el).attr('src');if( src) fotos.push(src.replace(/236/g, '736').replace('60x60', '736x'));});return {ok:true,criador:'Hiudy',result: fotos };} catch (err) {return {ok:false,msg:'Ocorreu um erro.'};};
};

module.exports = { search: pinterest };